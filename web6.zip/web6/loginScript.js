document.getElementById("loginForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    // Получаем данные из localStorage
    const storedEmail = localStorage.getItem("email");
    const storedPassword = localStorage.getItem("password");

    console.log("Entered email:", email);
    console.log("Entered password:", password);
    console.log("Stored email:", storedEmail);
    console.log("Stored password:", storedPassword);

    // Проверяем совпадение
    if (email === storedEmail && password === storedPassword) {
        alert("Login successful!");
        window.location.href = "index.html";
    } else {
        alert("Invalid email or password. Please try again.");
    }
});
